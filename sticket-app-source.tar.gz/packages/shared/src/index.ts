export type Id = string;

export type PrivacySetting = 'PUBLIC' | 'FRIENDS' | 'PRIVATE';



