// Legacy route kept for backwards compatibility.
// The onboarding flow uses `/(onboarding)/connect-spotify`.
export { default } from './connect-spotify';



