module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      // Keep Reanimated last.
      'react-native-reanimated/plugin',
    ],
  };
};



