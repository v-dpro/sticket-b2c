// Optional Redis client.
// If/when you want Redis, add a dependency (e.g. ioredis) and wire it here.

export const redis = null;
export default redis;



