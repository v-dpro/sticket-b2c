/**
 * Standard expo-router entry point.
 * This file is used when running from apps/mobile directory.
 */
import 'expo-router/entry';
