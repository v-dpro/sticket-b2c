// This screen is never shown - the center tab button handles navigation
import { View } from 'react-native';

export default function LogPlaceholder() {
  return <View />;
}



