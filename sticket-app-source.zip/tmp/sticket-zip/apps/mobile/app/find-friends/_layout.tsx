import { Stack } from 'expo-router';

export default function FindFriendsLayout() {
  return <Stack screenOptions={{ headerShown: false }} />;
}




